/*
  # Create Storage Bucket for Bottling Images

  1. Storage Setup
    - Create a storage bucket named 'bottling-images'
    - Set bucket to be private (not publicly accessible)
    - Configure file size limits and allowed MIME types

  2. Security Policies
    - Allow authenticated users to upload images to their own folder
    - Allow authenticated users to view their own images
    - Allow authenticated users to delete their own images
*/

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'bottling-images',
  'bottling-images',
  false,
  5242880,
  ARRAY['image/jpeg', 'image/png', 'image/jpg']
)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Users can upload their own images"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'bottling-images' AND
    (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "Users can view their own images"
  ON storage.objects FOR SELECT
  TO authenticated
  USING (
    bucket_id = 'bottling-images' AND
    (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "Users can delete their own images"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'bottling-images' AND
    (storage.foldername(name))[1] = auth.uid()::text
  );