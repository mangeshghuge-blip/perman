/*
  # Create Bottling Quality Data Entry System

  1. New Tables
    - `bottling_entries`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `entry_date` (date) - Date of the bottling entry
      - `brand_name` (text) - Brand name
      - `size` (text) - Bottle size (375ml, 750ml, 6L, etc.)
      - `bottle_manufacturer` (text) - Bottle manufacturer name
      - `label_supplier` (text) - Label supplier name
      - `batch_number` (text) - Batch number
      - `state` (text) - State
      - `mrp` (decimal) - Maximum Retail Price
      - `image_url` (text, nullable) - URL to uploaded image
      - `total_quantity` (integer) - Total quantity produced
      - `accepted_quantity` (integer) - Quantity accepted
      - `rejected_quantity` (integer) - Quantity rejected
      - `remarks` (text, nullable) - Additional remarks
      - `created_at` (timestamptz) - Record creation timestamp
      - `updated_at` (timestamptz) - Record update timestamp

  2. Security
    - Enable RLS on `bottling_entries` table
    - Add policy for authenticated users to read their own entries
    - Add policy for authenticated users to insert their own entries
    - Add policy for authenticated users to update their own entries
    - Add policy for authenticated users to delete their own entries

  3. Indexes
    - Add index on user_id for faster queries
    - Add index on entry_date for date-based filtering
    - Add index on batch_number for search functionality
*/

CREATE TABLE IF NOT EXISTS bottling_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  entry_date date NOT NULL DEFAULT CURRENT_DATE,
  brand_name text NOT NULL,
  size text NOT NULL,
  bottle_manufacturer text NOT NULL,
  label_supplier text NOT NULL,
  batch_number text NOT NULL,
  state text NOT NULL,
  mrp decimal(10, 2) NOT NULL,
  image_url text,
  total_quantity integer NOT NULL DEFAULT 0,
  accepted_quantity integer NOT NULL DEFAULT 0,
  rejected_quantity integer NOT NULL DEFAULT 0,
  remarks text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE bottling_entries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own bottling entries"
  ON bottling_entries FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own bottling entries"
  ON bottling_entries FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own bottling entries"
  ON bottling_entries FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own bottling entries"
  ON bottling_entries FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_bottling_entries_user_id ON bottling_entries(user_id);
CREATE INDEX IF NOT EXISTS idx_bottling_entries_entry_date ON bottling_entries(entry_date);
CREATE INDEX IF NOT EXISTS idx_bottling_entries_batch_number ON bottling_entries(batch_number);