export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export interface Database {
  public: {
    Tables: {
      bottling_entries: {
        Row: {
          id: string;
          user_id: string;
          entry_date: string;
          brand_name: string;
          size: string;
          bottle_manufacturer: string;
          label_supplier: string;
          batch_number: string;
          state: string;
          mrp: number;
          image_url: string | null;
          total_quantity: number;
          accepted_quantity: number;
          rejected_quantity: number;
          remarks: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          entry_date?: string;
          brand_name: string;
          size: string;
          bottle_manufacturer: string;
          label_supplier: string;
          batch_number: string;
          state: string;
          mrp: number;
          image_url?: string | null;
          total_quantity?: number;
          accepted_quantity?: number;
          rejected_quantity?: number;
          remarks?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          entry_date?: string;
          brand_name?: string;
          size?: string;
          bottle_manufacturer?: string;
          label_supplier?: string;
          batch_number?: string;
          state?: string;
          mrp?: number;
          image_url?: string | null;
          total_quantity?: number;
          accepted_quantity?: number;
          rejected_quantity?: number;
          remarks?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
    };
  };
}
