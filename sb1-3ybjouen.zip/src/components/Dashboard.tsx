import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Plus, Search, Download, Edit2, Trash2, LogOut, TrendingUp, CheckCircle, XCircle, Package } from 'lucide-react';
import { EntryForm } from './EntryForm';
import type { Database } from '../lib/database.types';

type BottlingEntry = Database['public']['Tables']['bottling_entries']['Row'];

interface DashboardStats {
  totalProduced: number;
  totalAccepted: number;
  totalRejected: number;
  totalEntries: number;
}

export function Dashboard() {
  const { user, signOut } = useAuth();
  const [entries, setEntries] = useState<BottlingEntry[]>([]);
  const [filteredEntries, setFilteredEntries] = useState<BottlingEntry[]>([]);
  const [stats, setStats] = useState<DashboardStats>({
    totalProduced: 0,
    totalAccepted: 0,
    totalRejected: 0,
    totalEntries: 0,
  });
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingEntry, setEditingEntry] = useState<BottlingEntry | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilter, setDateFilter] = useState('');
  const [brandFilter, setBrandFilter] = useState('');
  const [stateFilter, setStateFilter] = useState('');

  useEffect(() => {
    fetchEntries();
  }, [user]);

  useEffect(() => {
    applyFilters();
  }, [entries, searchTerm, dateFilter, brandFilter, stateFilter]);

  const fetchEntries = async () => {
    if (!user) return;

    setLoading(true);
    const { data, error } = await supabase
      .from('bottling_entries')
      .select('*')
      .order('entry_date', { ascending: false });

    if (error) {
      console.error('Error fetching entries:', error);
    } else {
      setEntries(data || []);
      calculateStats(data || []);
    }
    setLoading(false);
  };

  const calculateStats = (data: BottlingEntry[]) => {
    const stats = data.reduce(
      (acc, entry) => ({
        totalProduced: acc.totalProduced + entry.total_quantity,
        totalAccepted: acc.totalAccepted + entry.accepted_quantity,
        totalRejected: acc.totalRejected + entry.rejected_quantity,
        totalEntries: acc.totalEntries + 1,
      }),
      { totalProduced: 0, totalAccepted: 0, totalRejected: 0, totalEntries: 0 }
    );
    setStats(stats);
  };

  const applyFilters = () => {
    let filtered = [...entries];

    if (searchTerm) {
      filtered = filtered.filter(
        (entry) =>
          entry.brand_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          entry.batch_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
          entry.state.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (dateFilter) {
      filtered = filtered.filter((entry) => entry.entry_date === dateFilter);
    }

    if (brandFilter) {
      filtered = filtered.filter((entry) =>
        entry.brand_name.toLowerCase().includes(brandFilter.toLowerCase())
      );
    }

    if (stateFilter) {
      filtered = filtered.filter((entry) =>
        entry.state.toLowerCase().includes(stateFilter.toLowerCase())
      );
    }

    setFilteredEntries(filtered);
    calculateStats(filtered);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this entry?')) return;

    const { error } = await supabase.from('bottling_entries').delete().eq('id', id);

    if (error) {
      alert('Error deleting entry');
    } else {
      fetchEntries();
    }
  };

  const handleEdit = (entry: BottlingEntry) => {
    setEditingEntry(entry);
    setShowForm(true);
  };

  const handleFormSuccess = () => {
    setShowForm(false);
    setEditingEntry(null);
    fetchEntries();
  };

  const exportToExcel = async () => {
    const XLSX = await import('https://cdn.sheetjs.com/xlsx-0.20.0/package/xlsx.mjs');

    const exportData = filteredEntries.map((entry) => ({
      Date: entry.entry_date,
      'Brand Name': entry.brand_name,
      Size: entry.size,
      'Bottle Manufacturer': entry.bottle_manufacturer,
      'Label Supplier': entry.label_supplier,
      'Batch Number': entry.batch_number,
      State: entry.state,
      MRP: entry.mrp,
      'Total Quantity': entry.total_quantity,
      'Accepted Quantity': entry.accepted_quantity,
      'Rejected Quantity': entry.rejected_quantity,
      Remarks: entry.remarks || '',
      'Image URL': entry.image_url || '',
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Bottling Data');
    XLSX.writeFile(wb, `bottling-data-${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  if (showForm) {
    return (
      <div className="min-h-screen bg-slate-50 p-4 md:p-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-xl shadow-lg p-6 md:p-8">
            <h2 className="text-2xl font-bold text-slate-800 mb-6">
              {editingEntry ? 'Edit Entry' : 'New Entry'}
            </h2>
            <EntryForm
              entry={editingEntry}
              onSuccess={handleFormSuccess}
              onCancel={() => {
                setShowForm(false);
                setEditingEntry(null);
              }}
            />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold text-slate-800">Quality Control Dashboard</h1>
          <div className="flex items-center gap-3">
            <button
              onClick={exportToExcel}
              className="flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
            >
              <Download className="w-4 h-4" />
              Export Excel
            </button>
            <button
              onClick={() => signOut()}
              className="flex items-center gap-2 px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg transition-colors"
            >
              <LogOut className="w-4 h-4" />
              Sign Out
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-blue-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 font-medium">Total Entries</p>
                <p className="text-3xl font-bold text-slate-800 mt-1">{stats.totalEntries}</p>
              </div>
              <Package className="w-10 h-10 text-blue-500" />
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-orange-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 font-medium">Total Produced</p>
                <p className="text-3xl font-bold text-slate-800 mt-1">{stats.totalProduced.toLocaleString()}</p>
              </div>
              <TrendingUp className="w-10 h-10 text-orange-500" />
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-green-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 font-medium">Accepted</p>
                <p className="text-3xl font-bold text-slate-800 mt-1">{stats.totalAccepted.toLocaleString()}</p>
              </div>
              <CheckCircle className="w-10 h-10 text-green-500" />
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-red-500">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 font-medium">Rejected</p>
                <p className="text-3xl font-bold text-slate-800 mt-1">{stats.totalRejected.toLocaleString()}</p>
              </div>
              <XCircle className="w-10 h-10 text-red-500" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
          <div className="flex flex-col md:flex-row gap-4 mb-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Search by brand, batch number, or state..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
            <input
              type="date"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Filter by date"
            />
            <button
              onClick={() => {
                setSearchTerm('');
                setDateFilter('');
                setBrandFilter('');
                setStateFilter('');
              }}
              className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg transition-colors"
            >
              Clear Filters
            </button>
            <button
              onClick={() => setShowForm(true)}
              className="flex items-center gap-2 px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
            >
              <Plus className="w-5 h-5" />
              New Entry
            </button>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          {loading ? (
            <div className="p-8 text-center text-slate-600">Loading...</div>
          ) : filteredEntries.length === 0 ? (
            <div className="p-8 text-center text-slate-600">
              No entries found. Click "New Entry" to add your first record.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-50 border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Date</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Brand</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Size</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">Batch No</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-slate-600 uppercase">State</th>
                    <th className="px-4 py-3 text-right text-xs font-semibold text-slate-600 uppercase">Total</th>
                    <th className="px-4 py-3 text-right text-xs font-semibold text-slate-600 uppercase">Accepted</th>
                    <th className="px-4 py-3 text-right text-xs font-semibold text-slate-600 uppercase">Rejected</th>
                    <th className="px-4 py-3 text-center text-xs font-semibold text-slate-600 uppercase">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {filteredEntries.map((entry) => (
                    <tr key={entry.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-3 text-sm text-slate-700">{entry.entry_date}</td>
                      <td className="px-4 py-3 text-sm font-medium text-slate-800">{entry.brand_name}</td>
                      <td className="px-4 py-3 text-sm text-slate-700">{entry.size}</td>
                      <td className="px-4 py-3 text-sm text-slate-700">{entry.batch_number}</td>
                      <td className="px-4 py-3 text-sm text-slate-700">{entry.state}</td>
                      <td className="px-4 py-3 text-sm text-slate-700 text-right">{entry.total_quantity}</td>
                      <td className="px-4 py-3 text-sm text-green-600 text-right font-medium">{entry.accepted_quantity}</td>
                      <td className="px-4 py-3 text-sm text-red-600 text-right font-medium">{entry.rejected_quantity}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => handleEdit(entry)}
                            className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDelete(entry.id)}
                            className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
